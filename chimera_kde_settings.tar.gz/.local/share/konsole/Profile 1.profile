[Appearance]
Font=Hack,12,-1,7,400,0,0,0,0,0,0,0,0,0,0,1,,0,0

[Badge Options]
BadgeEnabled=false

[General]
Name=Profile 1
Parent=FALLBACK/
